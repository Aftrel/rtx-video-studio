# Registering the layer from your own application (Windows)

The Vulkan loader discovers **implicit** layers by scanning manifest JSON files referenced
by the `VK_ADD_LAYER_PATH` environment variable (or the registry / global implicit-layer
folders — not used here since we don't want a system-wide install). An application that
wants to drive lsfg-vk itself, rather than relying on a system-wide install, needs to do
three things **before creating its first `VkInstance`**:

1. Write a layer manifest with an **absolute** path to `liblsfg-vk-layer.dll` (see
   [`WINDOWS.md`](../../WINDOWS.md) gotcha #1 — a relative path is rejected outright).
2. Write the layer's own config (`conf.toml`, or set `LSFGVK_ENV=1` and the `LSFGVK_*`
   variables directly — see [`Configuration.md`](../Configuration.md)) with a profile whose
   `active_in` matches your process name.
3. Set `VK_ADD_LAYER_PATH` and `VK_INSTANCE_LAYERS=VK_LAYER_LSFGVK_frame_generation` in your
   *own* process's environment, then create the Vulkan instance as normal — the loader picks
   the layer up automatically.

[`register-layer.ps1`](register-layer.ps1) is a minimal, dependency-free reference
implementation of steps 1–3, usable standalone or as a template to port into your
application's own startup code (Rust, C++, C#, whatever — the steps translate directly:
write two files, set three environment variables, launch the child process or continue your
own startup).

It deliberately does **not** ship or reference any Lossless Scaling files — it only locates
an *already-installed* `Lossless.dll` on the machine it runs on, the same way you must in
your own integration.

## Usage

```powershell
# Locates Lossless.dll under Steam automatically; multiplier 5 == e.g. 24fps -> 120fps.
.\register-layer.ps1 -LayerDll "C:\path\to\liblsfg-vk-layer.dll" `
                      -ProcessName "mpv.exe" `
                      -Multiplier 5 `
                      -Launch "C:\path\to\mpv.exe" -LaunchArgs "--gpu-api=vulkan","--gpu-context=winvk","video.mkv"
```

Or, to just prepare the manifest/config/env and inspect them without launching anything, omit
`-Launch` — the script prints the environment variables it *would* set so you can wire the
equivalent calls into your own application's startup path.

## What a real integration looks like

A persistent application (a media player, a game launcher, an emulator front-end) typically:
- Keeps the layer DLL + manifest + a settings file of its own next to its executable.
- Regenerates the manifest with an absolute path at every startup (cheap, and avoids the
  manifest going stale if the install is moved).
- Derives `conf.toml` from its own UI/config rather than exposing raw lsfg-vk config to the
  user — e.g. a single "frame generation: on/off, multiplier" toggle that becomes a
  `[[profile]]` block with `active_in` set to the app's own exe name.
- Sets the three environment variables via `SetEnvironmentVariableW` (or the language
  equivalent) **before** its Vulkan/graphics backend initializes — and reads them back with
  the Win32 API rather than assuming its own CRT snapshot is current if any of that setup
  happens in a separate module (see `WINDOWS.md` gotcha #2).
