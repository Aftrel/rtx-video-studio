<#
.SYNOPSIS
    Minimal reference implementation for registering the lsfg-vk Windows layer with the
    Vulkan loader for a specific target process, without a system-wide install.

.DESCRIPTION
    Writes an absolute-path layer manifest (required — see WINDOWS.md gotcha #1), writes a
    matching lsfg-vk conf.toml scoped to -ProcessName, and sets the three environment
    variables the Vulkan loader and the layer itself read. Optionally launches -Launch with
    those variables applied.

    This script does not download, bundle, or reference any Lossless Scaling files beyond
    locating an already-installed Lossless.dll on the current machine.

.PARAMETER LayerDll
    Absolute or relative path to the built liblsfg-vk-layer.dll. Resolved to an absolute path.

.PARAMETER ProcessName
    Executable name (e.g. "mpv.exe") the layer should activate for.

.PARAMETER Multiplier
    Frame-generation multiplier (>= 2). Pick a value that divides your display's refresh
    rate evenly.

.PARAMETER LosslessDll
    Explicit path to the user's Lossless.dll. If omitted, common Steam library locations are
    scanned.

.PARAMETER WorkDir
    Where to write the generated manifest/config. Defaults to a "lsfg" folder next to this
    script.

.PARAMETER Launch
    Optional: path to an executable to launch with the layer environment applied.

.PARAMETER LaunchArgs
    Optional: arguments passed to -Launch.
#>
param(
    [Parameter(Mandatory = $true)][string]$LayerDll,
    [Parameter(Mandatory = $true)][string]$ProcessName,
    [int]$Multiplier = 2,
    [string]$LosslessDll,
    [string]$WorkDir = (Join-Path $PSScriptRoot "lsfg"),
    [string]$Launch,
    [string[]]$LaunchArgs = @()
)

$ErrorActionPreference = "Stop"
$LayerName = "VK_LAYER_LSFGVK_frame_generation"

function Find-LosslessDll {
    param([string]$Explicit)
    if ($Explicit -and (Test-Path $Explicit)) { return (Resolve-Path $Explicit).Path }

    $rel = "steamapps\common\Lossless Scaling\Lossless.dll"
    $candidates = foreach ($drive in @("C", "D", "E", "F", "G")) {
        Join-Path "${drive}:\Program Files (x86)\Steam" $rel
        Join-Path "${drive}:\SteamLibrary" $rel
    }
    foreach ($c in $candidates) {
        if (Test-Path $c) { return (Resolve-Path $c).Path }
    }
    return $null
}

if (-not (Test-Path $LayerDll)) {
    throw "Layer DLL not found at '$LayerDll'. Build it first (see ../../WINDOWS.md)."
}
$LayerDllAbs = (Resolve-Path $LayerDll).Path

$lossless = Find-LosslessDll -Explicit $LosslessDll
if (-not $lossless) {
    throw "Could not find Lossless.dll. Pass -LosslessDll explicitly, or install " +
          "Lossless Scaling via Steam first."
}

New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null

# --- 1. Manifest: library_path MUST be absolute (loader rejects relative -> error 87) ---
$manifestPath = Join-Path $WorkDir "$LayerName.json"
$manifest = @"
{
  "file_format_version": "1.1.0",
  "layer": {
    "name": "$LayerName",
    "description": "Lossless Scaling frame generation layer",
    "implementation_version": "2",
    "library_path": "$($LayerDllAbs -replace '\\','/')",
    "type": "GLOBAL",
    "api_version": "1.4.328",
    "disable_environment": { "DISABLE_LSFGVK": "1" }
  }
}
"@
Set-Content -Path $manifestPath -Value $manifest -Encoding utf8NoBOM

# --- 2. Config: one profile scoped to the target process ---
$confPath = Join-Path $WorkDir "lsfg-vk.toml"
$losslessFwd = $lossless -replace '\\', '/'
$conf = @"
version = 2

[global]
dll = '$losslessFwd'
allow_fp16 = true

[[profile]]
name = "$ProcessName"
active_in = [ '$ProcessName' ]
multiplier = $([Math]::Max(2, $Multiplier))
flow_scale = 1.00
performance_mode = false
pacing = 'none'
"@
Set-Content -Path $confPath -Value $conf -Encoding utf8NoBOM

# --- 3. Environment variables the loader and the layer itself read ---
$env:VK_ADD_LAYER_PATH = $WorkDir
$env:VK_INSTANCE_LAYERS = $LayerName
$env:LSFGVK_CONFIG = $confPath

Write-Host "Layer manifest : $manifestPath"
Write-Host "Layer config   : $confPath"
Write-Host "Lossless.dll   : $lossless"
Write-Host "VK_ADD_LAYER_PATH  = $($env:VK_ADD_LAYER_PATH)"
Write-Host "VK_INSTANCE_LAYERS = $($env:VK_INSTANCE_LAYERS)"
Write-Host "LSFGVK_CONFIG      = $($env:LSFGVK_CONFIG)"

if ($Launch) {
    if (-not (Test-Path $Launch)) { throw "Launch target not found: $Launch" }
    Write-Host "`nLaunching: $Launch $LaunchArgs"
    & $Launch @LaunchArgs
}
