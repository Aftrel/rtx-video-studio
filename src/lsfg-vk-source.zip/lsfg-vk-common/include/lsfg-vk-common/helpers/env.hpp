/* SPDX-License-Identifier: GPL-3.0-or-later */

#pragma once

#include <cstdlib>
#include <string>

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#endif

namespace ls {
    /// Read an environment variable.
    ///
    /// On Windows this uses GetEnvironmentVariableA rather than std::getenv: a host process that
    /// sets our LSFGVK_* variables via the Win32 API (SetEnvironmentVariableW) after its own
    /// startup may do so AFTER the C runtime captured its _environ snapshot, so std::getenv
    /// would not see them.
    /// The returned pointer is valid until the next ls_getenv call on the same thread.
    inline const char* ls_getenv(const char* name) {
#ifdef _WIN32
        thread_local std::string buffer;
        constexpr DWORD cap = 32767; // max env var length on Windows
        buffer.resize(cap);
        const DWORD len = GetEnvironmentVariableA(name, buffer.data(), cap);
        if (len == 0 || len >= cap)
            return nullptr;
        buffer.resize(len);
        return buffer.c_str();
#else
        return std::getenv(name);
#endif
    }
}
