/* SPDX-License-Identifier: GPL-3.0-or-later */

#pragma once

#include "../helpers/pointers.hpp"
#include "vulkan.hpp"

#include <optional>

#ifdef _WIN32
#include <windows.h>
#endif
#include <vulkan/vulkan_core.h>

namespace vk {
    /// vulkan semaphore
    class Semaphore {
    public:
        /// create a semaphore
        /// @param vk the vulkan instance
#ifdef _WIN32
        /// @param handle optional handle to import the semaphore from
#else
        /// @param fd optional file descriptor to import the semaphore from
#endif
        /// @throws ls::vulkan_error on failure
        Semaphore(const vk::Vulkan& vk,
#ifdef _WIN32
            std::optional<HANDLE> handle = std::nullopt
#else
            std::optional<int> fd = std::nullopt
#endif
            );

        /// get the underlying VkSemaphore handle
        /// @return the VkSemaphore handle
        [[nodiscard]] const auto& handle() const { return *this->semaphore; }
    private:
        ls::owned_ptr<VkSemaphore> semaphore;
    };
}
