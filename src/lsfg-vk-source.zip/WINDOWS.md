# Windows port notes

This fork adds a native Windows build of [lsfg-vk](https://github.com/PancakeTAS/lsfg-vk),
PancakeTAS's Vulkan layer that drives **Lossless Scaling**'s frame-generation algorithm.
Upstream targets Linux; Lossless Scaling itself is Windows-only, so this port lets any
Vulkan application on Windows get LS-quality frame generation without going through the
official LS overlay/capture path.

All of it is layered behind `#ifdef _WIN32` next to the existing Linux code — nothing
Linux-specific was removed or restructured. If you're comparing against upstream, everything
below is the diff.

## What changed

| File | Change |
|---|---|
| `lsfg-vk-common/include/.../vulkan/*.hpp`, `vulkan/*.cpp` | Windows external-memory/semaphore import via `VK_KHR_external_memory_win32` / `VK_KHR_external_semaphore_win32`, using `HANDLE` in place of the Linux `VK_KHR_external_memory_fd` file descriptor. `ShareHandle` is aliased to `HANDLE` on Windows, `int` on Linux — one code path serves both (`lsfg-vk-backend/include/.../lsfgvk.hpp`). |
| `lsfg-vk-common/include/.../helpers/env.hpp` | `ls_getenv()` uses `GetEnvironmentVariableA` instead of `std::getenv` on Windows (see gotcha #2 below). |
| `lsfg-vk-common/src/configuration/detection.cpp` | Process-name detection via `GetModuleFileNameA` (no `/proc` on Windows). |
| `lsfg-vk-layer/src/instance.cpp` | `VK_KHR_external_memory_win32` / `_semaphore_win32` requested instead of the `_fd` variants; `_putenv_s` instead of `setenv`/`unsetenv` for the recursion guard. |
| `CMakeLists.txt` | `VK_USE_PLATFORM_WIN32_KHR`, `NOMINMAX`, `WIN32_LEAN_AND_MEAN` defined under `if(WIN32)`. |
| `lsfg-vk-layer/CMakeLists.txt` | Static-links the mingw runtime (`-static -static-libgcc -static-libstdc++`) on Windows — see gotcha #1. |

No shaders, DLLs, or other Lossless Scaling assets are part of this diff or this repo. The
layer only ever reads `Lossless.dll` — a file the *user* already owns via their own
purchase — at runtime, via a PE resource-table parser (`lsfg-vk-backend/src/extraction/dll_reader.cpp`,
unchanged from upstream). Nothing extracted from it is written to disk or redistributed.

## Toolchain

- **MinGW-w64 GCC or Clang**, target UCRT. The layer statically links the mingw runtime
  (`-static -static-libgcc -static-libstdc++`, see gotcha #1) — a mingw/GCC-family flag, not
  applicable to MSVC. Building with MSVC is not currently supported; porting it would require
  an equivalent static-CRT setting (`/MT`) and reworking that link step.
- **Ninja** (or any CMake generator).
- **Vulkan SDK ≥ 1.4.328** on the include path (`CPATH` or equivalent) — the layer manifest
  declares `api_version 1.4.328`.

## Build

```bash
export VULKAN_SDK=/c/VulkanSDK/<version>
export CPATH="$VULKAN_SDK/Include"
cmake -S . -B build_win -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER=g++ \
  -DLSFGVK_BUILD_UI=OFF -DLSFGVK_BUILD_CLI=OFF -DLSFGVK_BUILD_VK_LAYER=ON \
  -DLSFGVK_LAYER_LIBRARY_PATH="<ABSOLUTE path to build_win/lsfg-vk-layer/liblsfg-vk-layer.dll>"
cmake --build build_win
```

This produces `build_win/lsfg-vk-layer/liblsfg-vk-layer.dll` and a generated
`VkLayer_LSFGVK_frame_generation.json` next to it.

## Gotchas

1. **The layer manifest's `library_path` must be an absolute path.** The Vulkan loader loads
   layer DLLs via `LoadLibraryEx` with `LOAD_LIBRARY_SEARCH_*` flags, which reject a relative
   path (loader error 87, `ERROR_INVALID_PARAMETER`) — the layer then fails to load, silently.
   Pass an absolute path to `LSFGVK_LAYER_LIBRARY_PATH` at configure time, or regenerate the
   manifest at runtime with an absolute path if the install location is only known then (see
   `docs/windows-integration-example/`).

2. **`ls_getenv()` uses `GetEnvironmentVariableA`, not `std::getenv`, by design.** A host
   process that sets the layer's `LSFGVK_*` environment variables via the Win32 API
   (`SetEnvironmentVariableW`) after its own C runtime has already snapshotted `_environ`
   will not be visible to `std::getenv` in the layer's own CRT — each DLL/EXE can carry its
   own CRT with its own stale `_environ` copy. `GetEnvironmentVariableA` reads the process's
   live environment block directly, avoiding that staleness.

3. **A `vkCreateSwapchainKHR` proc-addr failure in the log does not indicate a broken layer.**
   It is logged for non-graphical (compute-only) `VkDevice`s, which legitimately have no
   swapchain functions to fetch — some applications create such a device (e.g. for a
   capability probe) before creating the real presenting device. The failure is caught and
   logged, not propagated; the presenting device attaches without logging anything on
   success. Verify frame generation is or isn't working via a frame-rate measurement, not via
   the presence of this line.

## Registering the layer for your own application

Nothing in this repo auto-registers itself with the Vulkan loader — that's the integrating
application's responsibility (set `VK_ADD_LAYER_PATH` / `VK_INSTANCE_LAYERS` and write the
layer's `conf.toml` before creating a Vulkan instance). See
[`docs/windows-integration-example/`](docs/windows-integration-example/) for a small,
app-agnostic example of exactly that.

## Choosing a multiplier

Pick a multiplier that divides the display's refresh rate evenly by the source frame rate —
e.g. a 24 fps source at `multiplier=5` on a 120 Hz display lands exactly on 120 fps.
A multiplier that produces an output rate the display can't evenly present (e.g. 48 fps on a
120 Hz panel) will judder, since the cadence doesn't align with the panel's refresh.
